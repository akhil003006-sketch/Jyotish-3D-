Vaidik Jyotish 3D Gurukul - educational prototype
Open index.html in Chrome on Android. This is an offline-capable single HTML file.
The astronomy animation is symbolic/educational, not a physically accurate 3D ephemeris.
The nakshatra longitude calculator assumes the entered value is already nirayana longitude.
This folder is not an installable APK. To create APK, wrap index.html in an Android WebView project and build/sign it with a compatible Android build toolchain.
